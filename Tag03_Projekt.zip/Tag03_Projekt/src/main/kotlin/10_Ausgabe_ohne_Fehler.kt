fun main(){
    var aufgabe : String= "nice"
    var test : Int = 1
    var bool : Boolean = false

    //Gib die drei Variablen auf der Konsole aus ohne einen Compiler- oder Laufzeitfehler
    println("$aufgabe "+" $test "+" $bool")
}