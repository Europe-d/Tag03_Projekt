fun main(){
    var test: String = "hallo Welt!"
    var test2: Int = 12345
    test = "Bis next jahre"
    test2 = 12345
    println("$test" + "$test2")
}