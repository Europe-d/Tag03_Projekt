fun main(){
    var zahl: Int = 23
    println("$zahl")
    var zahl1: String = "Hallo Welt"
    println("$zahl1")
}