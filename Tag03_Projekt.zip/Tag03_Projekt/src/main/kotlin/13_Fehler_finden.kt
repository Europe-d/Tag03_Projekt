fun main(){
    var fehler: String = "geht das?"
    println("$fehler")
}