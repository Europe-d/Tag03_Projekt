fun main(){
    var fehler : Boolean = true
    var fehler1 : String = "ja"

    println("Gibt es einen Fehler? " + "$fehler1")
}