fun main(){
    var isDead : Boolean = true
    var player : String = " Magier "

    if(isDead){
        println("Der" + "$player" + "ist gestorben")
    }
    else{
        println("Der" + "$player" + "ist am Leben!")
    }
}