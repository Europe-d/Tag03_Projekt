fun main(){
    // Hier sind Compilerfehler, die behoben werden sollen
    var test : Int = 0
    var test1 : Int = 1
}
