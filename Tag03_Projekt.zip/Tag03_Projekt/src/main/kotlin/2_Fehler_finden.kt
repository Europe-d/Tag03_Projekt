fun main(){
    // Hier sind Compilerfehler, die behoben werden sollen
    var test1 : Boolean
    var test2 = true
    println("test1")
    println("test2")
}