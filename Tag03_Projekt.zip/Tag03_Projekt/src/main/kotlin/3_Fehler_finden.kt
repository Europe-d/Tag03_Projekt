fun main(){
    // Hier ist ein Compilerfehler, der behoben werden soll

    var str : Int = 145
    println(str)
}