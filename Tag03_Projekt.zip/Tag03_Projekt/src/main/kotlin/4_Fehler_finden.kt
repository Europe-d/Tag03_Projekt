fun main(){
    // Behebe die Compilerfehler und lasse das Programm durchlaufen
    var test : Int = 123
    var test1 : Int = 456
    println(test+test1)
}