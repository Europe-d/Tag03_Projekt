fun main(){

var name : String = ("ist Evropi")
var age : Int = 36
var grosse : Double = 1.71

var allgemein: String = "keine ahnung"
}