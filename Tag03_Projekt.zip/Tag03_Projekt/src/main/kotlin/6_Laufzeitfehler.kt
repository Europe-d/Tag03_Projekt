fun main(){
    //Behebe den Laufzeitfehler
    var test1:Int = 10
    var test2:Int = 5
    println(test1/test2)
}