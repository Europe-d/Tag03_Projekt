fun main(){
    // Behebe die Exception
    var test:String = "Hallo Welt"
    var test2: String = "test"
    println(test2)
}