fun main(){
    var test: String = "Kannst du mich hören?"
    var test2: String = "HalloWelt!"

    println("$test2 $test") // <---- Unwichtig, was das bedeutet, hier ist der Fehler nicht zu finden.
}