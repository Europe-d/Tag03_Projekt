fun main(){
    var test1: Boolean = true
    var test2: String = "test"
    var test3: String = "a"

    println ("$test2+$test3")

}